// import { useRoute } from 'vue-router'
// import { useUserStore } from '@/stores/userStore.js'

// export function useLogOut() {

//     function logOut() {
//         const user = useUserStore()
//         const route = useRoute()

//         console.log(user)
//         console.log(route);
//     }

//     return { logOut }

// }