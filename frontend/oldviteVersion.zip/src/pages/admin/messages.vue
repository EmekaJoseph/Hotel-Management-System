<template>
    <div>
        <sideBarComponent />
        <div class="adminMain">Notifications</div>
    </div>
</template>

<script setup>

</script>

<style scoped>
</style>