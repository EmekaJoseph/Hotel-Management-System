<template>
    <div>
        <sideBarComponent />
        <div class="adminMain">Rooms</div>
    </div>
</template>

<script setup>
// import sideBarComponent from '@/components/admin/sideBarComponent.vue'

</script>

<style scoped>
</style>