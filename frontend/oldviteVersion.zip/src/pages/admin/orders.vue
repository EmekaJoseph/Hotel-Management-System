<template>
    <div>
        <sideBarComponent />
        <div class="adminMain">Bookings</div>
    </div>
</template>

<script setup>

</script>

<style scoped>
</style>