<template>
    <div>
        <headerComponent />
        <topPageCard>
            <h2 class="fw-bold text-center">Our Gallery</h2>
        </topPageCard>
        <footerComponent />
    </div>
</template>

<script setup>
    import topPageCard from '@/components/general//topPageCardComponent.vue';

</script>

<style scoped>

</style>