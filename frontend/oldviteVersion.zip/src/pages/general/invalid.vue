<template>
    <div>
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
        Invalid page
    </div>
</template>

<script setup>

</script>

<style scoped>

</style>