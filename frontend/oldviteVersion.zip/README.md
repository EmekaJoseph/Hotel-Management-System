# Vue 3 + Vite

"# Hotel-Management-System" 


A hotel management system with vue js and codeigniter(php frameworks)


## Recommended IDE Setup

- [VSCode](https://code.visualstudio.com/) + [Volar](https://marketplace.visualstudio.com/items?itemName=johnsoncodehk.volar)
